# BBS SG Bank (synthetic) COBOL batch
Fictional educational example. Run a nightly batch of deposits (D), withdrawals (W), and transfers (T) against a flat-file account ledger. Entry point: bank.cob.
accounts.dat: account ID (8 digits)|balance (12-digit integer cents).
operations.dat: type|source ID|destination ID|amount (12-digit integer cents).
The program reads and rewrites the entire account file for each valid operation, illustrating a deliberate I/O scaling bottleneck. No real bank/customer records.
Modernization objective: preserve cent-accurate balances, rejections, and fixed-width output; replace per-operation scans with indexed lookups and a single write per batch; validate by COBOL/Python parity benchmark.
